ALL *.mcfunction files included with this DATAPACK are created and owned by FlailoftheLord.
ANY modifications, whatsoever, are taken at the user's risk and this Map is not guaranteed to be playable if modified.
